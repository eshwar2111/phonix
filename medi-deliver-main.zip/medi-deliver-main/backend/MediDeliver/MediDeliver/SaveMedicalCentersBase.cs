﻿using Microsoft.Extensions.Logging;

namespace Medi_Deliver
{
    public class SaveMedicalCentersBase
    {
        private readonly ILogger _logger;

    }
}