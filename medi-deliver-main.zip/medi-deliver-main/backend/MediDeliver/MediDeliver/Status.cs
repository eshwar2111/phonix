﻿namespace Medi_Deliver
{
   
        public enum Status { Recived, Packing, On_the_way, Delivered }


    }
