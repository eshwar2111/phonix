# medi-deliver
Medicine delivery app for pharmacies 
