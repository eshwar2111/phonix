import React from 'react'
import DashBoard from '../components/dash-board/dash-board'



const home = () => {
    return (
        <div>
     
     hello world
     </div>
  
       
    )
}

export default home