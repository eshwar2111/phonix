import React from 'react'
import LoginForm from '../components/login-form/login-form'


const login = () => {
    return (
       <LoginForm/>
       
    )
}

export default login