package com.example.medi_care_appliaction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
